# Pawtism Client 1.1.0

## Install

1. Create a Fabric instance for Minecraft 26.2.
2. Use Java 25 or newer and Fabric Loader 0.19.5 or newer.
3. Copy the five JARs from `mods/` into your instance's `mods/` folder.
4. Launch Minecraft and press **Right Shift**.

Keep only one version of Pawtism and each library installed.

## Controls

- **Right Shift:** module browser
- **Hold Z:** zoom
- **N:** waypoints
- **B:** waypoint markers

## Included

- Pawtism Client 1.1.0 for Minecraft 26.2
- Fabric API 0.161.0+26.2
- MaLiLib 0.29.6
- Mod Menu 20.0.3
- Text Placeholder API 3.1.0-beta.1+26.2

## More information

- [Features](docs/FEATURES.md)
- [Controls](docs/CONTROLS.md)
- [Library notices](THIRD_PARTY_NOTICES.md)
- [Project and releases](https://github.com/AidenRTRRgfdm/Pawtism-Client)
