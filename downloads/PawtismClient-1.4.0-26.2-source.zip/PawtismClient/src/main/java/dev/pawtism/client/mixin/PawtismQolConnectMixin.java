package dev.pawtism.client.mixin;
import dev.pawtism.client.qol.QolModules;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.TransferState;
import net.minecraft.client.multiplayer.resolver.ServerAddress;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ConnectScreen.class)
public abstract class PawtismQolConnectMixin {
    @Inject(method = "startConnecting", at = @At("HEAD"))
    private static void pawtism$rememberTarget(Screen parent, Minecraft mc, ServerAddress address, ServerData server,
                                              boolean quickPlay, TransferState transfer, CallbackInfo ci) {
        QolModules.rememberServer(server);
    }
}
